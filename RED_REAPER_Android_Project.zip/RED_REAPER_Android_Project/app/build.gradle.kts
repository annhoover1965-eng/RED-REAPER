plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.redreaper.companion"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.redreaper.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-preview"
    }
}
