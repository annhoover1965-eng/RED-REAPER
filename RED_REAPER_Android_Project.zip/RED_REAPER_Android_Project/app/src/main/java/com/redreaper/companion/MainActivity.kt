package com.redreaper.companion

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val red = Color.rgb(242, 59, 69)
    private val dark = Color.rgb(24, 19, 21)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "RED REAPER"
            textSize = 30f
            setTextColor(red)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "BTD6 COMPANION • ANDROID PREVIEW"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        val explanation = TextView(this).apply {
            text = "This is the first Android companion-app shell. It can show a floating menu over other apps after you grant permission. Its switches are interface controls only; they do not modify Bloons TD 6."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val permission = makeButton("1. Grant display-over-apps permission")
        permission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        val start = makeButton("2. Start RED REAPER floating button")
        start.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                val intent = Intent(this, OverlayService::class.java)
                startForegroundService(intent)
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val stop = makeButton("Stop floating menu")
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }
        val warning = TextView(this).apply {
            text = "Note: Android may show a persistent notification while the floating menu is active. You can stop it here or from the notification."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(explanation)
        layout.addView(permission, fullWidth())
        layout.addView(start, fullWidth())
        layout.addView(stop, fullWidth())
        layout.addView(warning)
        setContentView(layout)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(red)
        setPadding(12, 8, 12, 8)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 7, 0, 7) }
}
