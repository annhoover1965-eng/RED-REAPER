package com.redreaper.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.CheckBox
import android.widget.SeekBar

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private val red = Color.rgb(242, 59, 69)
    private val bg = Color.rgb(25, 19, 22)
    private val card = Color.rgb(47, 34, 39)
    private val white = Color.WHITE
    private val mainMods = listOf(
        "Infinite Money", "Infinite Lives", "Unlock All Towers", "Fast Attack Speed",
        "God Mode", "Instant Ability Cooldown", "Max Tower Upgrades", "Custom Bloon Spawner"
    )

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        createBubble()
    }

    private fun startAsForeground() {
        val channelId = "red_reaper_overlay"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                channelId, "RED REAPER floating menu", NotificationManager.IMPORTANCE_LOW
            ))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }.setContentTitle("RED REAPER is active")
            .setContentText("Tap the red floating button to open the companion menu.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        startForeground(42, notification)
    }

    private fun overlayParams(width: Int, height: Int, gravity: Int) =
        WindowManager.LayoutParams(
            width, height,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

    private fun createBubble() {
        val button = TextView(this).apply {
            text = "RR"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            gravity = Gravity.CENTER
            setBackgroundColor(red)
            elevation = 12f
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubbleParams = overlayParams(58, 58, Gravity.TOP or Gravity.END).apply {
            x = 18; y = 220
        }
        var startX = 0f; var startY = 0f; var initialX = 0; var initialY = 0
        button.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = bubbleParams.x; initialY = bubbleParams.y
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    bubbleParams.x = (initialX + startX - event.rawX).toInt()
                    bubbleParams.y = (initialY + event.rawY - startY).toInt()
                    try { wm.updateViewLayout(button, bubbleParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        bubble = button
        wm.addView(button, bubbleParams)
    }

    private fun showPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "RED REAPER"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(red)
        }
        val close = Button(this).apply {
            text = "×"; textSize = 20f; setTextColor(white); setBackgroundColor(red)
            setOnClickListener { hidePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(close, LinearLayout.LayoutParams(48, 46))
        outer.addView(header)
        val note = TextView(this).apply {
            text = "COMPANION PREVIEW • switches do not alter BTD6"
            textSize = 10f; setTextColor(Color.LTGRAY); setPadding(0, 5, 0, 10)
        }
        outer.addView(note)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addSection(content, "MAIN MODS")
        mainMods.forEach { name ->
            val check = CheckBox(this).apply {
                text = name; textSize = 14f; setTextColor(white)
                buttonTintList = android.content.res.ColorStateList.valueOf(red)
                setPadding(4, 5, 4, 5)
            }
            content.addView(check)
        }
        addSection(content, "TOWER CUSTOMIZER")
        addInfo(content, "Choose any tower, then adjust damage, attack speed, range, and visual-effect concepts in a future editor.")
        addSlider(content, "Damage multiplier (preview)", 1, 100)
        addSlider(content, "Attack speed (preview)", 1, 100)
        addSlider(content, "Range (preview)", 1, 20)
        addSection(content, "PARAGON LAB")
        addInfo(content, "Official Paragons, fan-made Paragons for every tower, and Degree 1–100 concepts.")
        addSlider(content, "Paragon degree", 1, 100)
        addSection(content, "GACHA MONKEY")
        listOf("Spawn Gacha Monkey (concept)", "Custom skins", "Custom rewards", "Unlimited spins (concept)").forEach {
            content.addView(CheckBox(this).apply { text = it; setTextColor(white); textSize = 14f })
        }
        addSection(content, "SANDBOX")
        listOf("Spawn Paragons (concept)", "Multiple Paragons (concept)", "Custom Bloon spawner (concept)").forEach {
            content.addView(CheckBox(this).apply { text = it; setTextColor(white); textSize = 14f })
        }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        panelParams = overlayParams(310, 540, Gravity.CENTER)
        panel = outer
        wm.addView(outer, panelParams)
    }

    private fun addSection(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(red); setPadding(0, 13, 0, 5)
        })
    }

    private fun addInfo(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 3, 0, 8)
        })
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int) {
        addInfo(parent, "$label: $min")
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
        }
        parent.addView(seek)
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
