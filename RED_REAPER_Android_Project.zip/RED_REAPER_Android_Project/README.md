# RED REAPER Android companion — preview source

This is a native Android project for a red/black floating companion menu. It is **not a BTD6 mod** and its controls do not alter game state.

## What's included
- Android app shell
- Permission flow for Android's display-over-other-apps permission
- Foreground service and draggable floating `RR` button
- Floating menu with main-mod switches, tower sliders, Paragon degree slider, Gacha Monkey and Sandbox concept sections
- Portrait/landscape support
- GitHub Actions workflow to build a debug APK in the cloud

## Build a debug APK using GitHub Actions (phone-friendly, but requires a GitHub account)
1. Create a new empty repository on GitHub.
2. Upload the contents of this project, preserving folder structure.
3. Open the repository's **Actions** tab.
4. Run **Build RED REAPER APK** (or push to `main`).
5. Open the completed workflow run, download the `RED-REAPER-debug-apk` artifact, and extract `app-debug.apk`.
6. Transfer/install the APK on your Android phone. Android will ask you to allow installation from the browser/file manager you used.

## First launch
1. Open RED REAPER.
2. Tap the button to grant display-over-apps permission.
3. Return to RED REAPER and tap Start.
4. A small red `RR` bubble appears. Tap it to open/close the panel. Drag it to move it.
5. Stop it from the app or notification.

## Android notes
- Minimum Android version: Android 8.0 (API 26).
- Target SDK: 35.
- A foreground notification is shown while the overlay service is active.
- Android may require the user to grant notification permission separately.
- Some devices restrict overlays over security-sensitive screens.
- The menu is a standalone companion overlay. No game memory editing, injection, save editing, currency manipulation, unlock bypass, or anti-cheat bypass is implemented.
- Actual BTD6 integration requires a compatible, lawful Android mod loader and game-version-specific mod API. This project does not include one.

## Build locally
Requires JDK 17, Android SDK 35, and Gradle 8.9:
`gradle assembleDebug`
